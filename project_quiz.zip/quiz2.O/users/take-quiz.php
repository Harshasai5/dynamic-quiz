<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: user-login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if (!isset($_GET['task_id'])) {
    echo "Invalid task.";
    exit();
}

$task_id = intval($_GET['task_id']);

// Get task details
$task_res = $conn->query("SELECT task_title FROM tasks WHERE id = $task_id");
$task = $task_res->fetch_assoc();
if (!$task) {
    echo "Task not found.";
    exit();
}

// Fetch questions and options
$questions = $conn->query("
    SELECT q.id AS qid, q.question_text, o.id AS oid, o.option_text 
    FROM questions q 
    JOIN options o ON q.id = o.question_id 
    WHERE q.task_id = $task_id 
    ORDER BY q.id
");

$quiz_data = [];
while ($row = $questions->fetch_assoc()) {
    $qid = $row['qid'];
    if (!isset($quiz_data[$qid])) {
        $quiz_data[$qid] = [
            'question_text' => $row['question_text'],
            'options' => []
        ];
    }
    $quiz_data[$qid]['options'][] = [
        'id' => $row['oid'],
        'text' => $row['option_text']
    ];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($task['task_title']) ?> - Quiz</title>
    <link rel="stylesheet" href="user-style.css">
</head>
<body>
    <h2><?= htmlspecialchars($task['task_title']) ?> - Quiz</h2>
    <form action="submit-quiz.php" method="post">
        <input type="hidden" name="task_id" value="<?= $task_id ?>">

        <?php $qno = 1; foreach ($quiz_data as $qid => $q): ?>
            <div class="question-block">
                <p><strong>Q<?= $qno++ ?>. <?= htmlspecialchars($q['question_text']) ?></strong></p>
                <?php foreach ($q['options'] as $opt): ?>
                    <label>
                        <input type="radio" name="answers[<?= $qid ?>]" value="<?= $opt['id'] ?>" required>
                        <?= htmlspecialchars($opt['text']) ?>
                    </label><br>
                <?php endforeach; ?>
            </div>
            <hr>
        <?php endforeach; ?>

        <button type="submit">Submit Answers</button>
    </form>
</body>
</html>
