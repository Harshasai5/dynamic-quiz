<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: user-login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'Learner';

// Get all registered course IDs for this user
$reg_result = $conn->query("SELECT DISTINCT tasks.course_id FROM user_attempts 
    JOIN tasks ON user_attempts.task_id = tasks.id
    WHERE user_attempts.user_id = $user_id");

$registered_courses = [];
while ($row = $reg_result->fetch_assoc()) {
    $registered_courses[] = $row['course_id'];
}

// Get all courses
$courses = $conn->query("SELECT * FROM courses");
if (!$courses) {
    die("Error fetching courses: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="dashboard-style.css"> <!-- Custom CSS -->
</head>
<body>
    <!-- Top Navigation Bar -->
    <div class="top-bar">
        <div class="user-info">
            <img src="assets/profile.png" class="profile-icon" alt="Profile Icon" />
            <span>Hi, <?= htmlspecialchars($user_name) ?></span>
        </div>
        <a href="logout.php" class="logout-button">Logout</a>
    </div>

    <!-- Page Title -->
    <h1 class="dashboard-title">TEST YOUR SKILLS</h1>

    <!-- Search Input -->
    <div class="search-container">
        <input type="text" id="searchInput" onkeyup="searchCourses()" placeholder="🔍 Search course name">
    </div>

    <!-- Continue Learning Section -->
    <div class="section-title">Continue learning:</div>
    <div class="courses-container">
        <?php
        foreach ($registered_courses as $cid):
            $cdata = $conn->query("SELECT * FROM courses WHERE id = $cid")->fetch_assoc();
            if (!$cdata) continue;

            // Calculate progress: total attempts vs total tasks in course
            $total_tasks = $conn->query("SELECT COUNT(*) AS total FROM tasks WHERE course_id = $cid")->fetch_assoc()['total'] ?? 1;
            $attempted_tasks = $conn->query("SELECT COUNT(DISTINCT task_id) AS done FROM user_attempts WHERE user_id = $user_id AND task_id IN (SELECT id FROM tasks WHERE course_id = $cid)")->fetch_assoc()['done'] ?? 0;
            $progress = round(($attempted_tasks / $total_tasks) * 100);
        ?>
            <div class="course-card">
                <img src="assets/<?= strtolower($cdata['course_name']) ?>.png" class="course-icon" alt="<?= $cdata['course_name'] ?>">
                <h3><?= htmlspecialchars($cdata['course_name']) ?></h3>
                <div class="progress-bar">
                    <div class="progress" style="width: <?= $progress ?>%;"></div>
                </div>
                <?php if ($attempted_tasks >= $total_tasks): ?>
                    <a href="export-course.php?course_id=<?= $cdata['id'] ?>" class="final-btn">Final Result</a>
                <?php else: ?>
                    <a href="get-tasks.php?course_id=<?= $cdata['id'] ?>" class="continue-btn">continue</a>
                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
    </div>

    <!-- All Courses Section -->
    <div class="section-title">All courses:</div>
    <div class="courses-container">
        <?php
        $courses->data_seek(0);
        while ($c = $courses->fetch_assoc()):
            $isRegistered = in_array($c['id'], $registered_courses);
        ?>
            <div class="course-card">
                <img src="assets/<?= strtolower($c['course_name']) ?>.png" class="course-icon" alt="<?= $c['course_name'] ?>">
                <h3><?= htmlspecialchars($c['course_name']) ?></h3>
                <?php if ($isRegistered): ?>
                    <a href="get-tasks.php?course_id=<?= $c['id'] ?>" class="continue-btn">continue</a>
                <?php else: ?>
                    <a href="get-tasks.php?course_id=<?= $c['id'] ?>" class="quiz-btn">Take QUIZ</a>
                <?php endif; ?>
            </div>
        <?php endwhile; ?>
    </div>

    <!-- Course Search Script -->
    <script>
        function searchCourses() {
            const input = document.getElementById("searchInput").value.toLowerCase();
            document.querySelectorAll(".course-card").forEach(card => {
                const name = card.querySelector("h3").textContent.toLowerCase();
                card.style.display = name.includes(input) ? "block" : "none";
            });
        }
    </script>
</body>
</html>