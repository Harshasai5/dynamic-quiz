<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: user-login.php");
    exit();
}

if (!isset($_GET['course_id'])) {
    die("Invalid course.");
}

$user_id = $_SESSION['user_id'];
$course_id = intval($_GET['course_id']);

// Fetch course name
$course_res = $conn->query("SELECT course_name FROM courses WHERE id = $course_id");
$course_name = $course_res->fetch_assoc()['course_name'] ?? 'Course';

// Fetch scores per task
$sql = "
    SELECT 
        t.id AS task_id,
        t.task_title,
        COUNT(*) AS total_questions,
        SUM(ua.user_answer = ua.correct_answer) AS correct_answers
    FROM user_attempts ua
    JOIN tasks t ON ua.task_id = t.id
    WHERE ua.user_id = $user_id AND t.course_id = $course_id
    GROUP BY t.id, t.task_title
    ORDER BY t.id
";

$result = $conn->query($sql);
$scores = [];
while ($row = $result->fetch_assoc()) {
    $scores[] = [
        'task_title' => $row['task_title'],
        'correct' => $row['correct_answers'],
        'total' => $row['total_questions']
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($course_name) ?> - Final Result</title>
    <link rel="stylesheet" href="final-result.css">
</head>
<body>

    <a href="user-dashboard.php" class="back-btn">← Back</a>

    <div class="download-banner">
        <p><strong>Download your answer</strong></p>
        <a href="export-csv.php?course_id=<?= $course_id ?>">CLICK</a>
    </div>

    <h1 class="title">Congratulations</h1>
    <p class="subtitle">Successfully completed <?= htmlspecialchars($course_name) ?> course Quiz</p>

    <div class="score-box">
        <table>
            <tr>
                <th>SCORES</th>
                <th></th>
            </tr>
            <?php foreach ($scores as $row): ?>
                <tr>
                    <td><?= htmlspecialchars($row['task_title']) ?></td>
                    <td><?= $row['correct'] ?>/<?= $row['total'] ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>

</body>
</html>
