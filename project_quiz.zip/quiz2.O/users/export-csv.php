<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: user-login.php");
    exit();
}

if (!isset($_GET['course_id'])) {
    die("Invalid course.");
}

$user_id = $_SESSION['user_id'];
$course_id = intval($_GET['course_id']);

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename="course_results.csv"');

$output = fopen("php://output", "w");
fputcsv($output, ['Task Title', 'Question', 'Your Answer', 'Correct Answer']);

$sql = "
SELECT 
    t.task_title,
    q.question_text,
    ua.user_answer,
    ua.correct_answer
FROM user_attempts ua
JOIN tasks t ON ua.task_id = t.id
JOIN questions q ON ua.question_id = q.id
WHERE ua.user_id = $user_id AND t.course_id = $course_id
ORDER BY t.task_title, q.id
";

$res = $conn->query($sql);
while ($row = $res->fetch_assoc()) {
    fputcsv($output, [
        $row['task_title'],
        $row['question_text'],
        $row['user_answer'],
        $row['correct_answer']
    ]);
}
fclose($output);
exit();
