<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: user-login.php");
    exit();
}

if (!isset($_GET['task_id'])) {
    echo "Invalid task!";
    exit();
}

$task_id = intval($_GET['task_id']);
$user_id = $_SESSION['user_id'];

$current = isset($_GET['q']) ? intval($_GET['q']) : 0;

$task_res = $conn->query("SELECT * FROM tasks WHERE id = $task_id");
$task = $task_res->fetch_assoc();

$questions_res = $conn->query("SELECT * FROM questions WHERE task_id = $task_id");
$questions = [];
while ($q = $questions_res->fetch_assoc()) {
    $q_id = $q['id'];
    $options_res = $conn->query("SELECT * FROM options WHERE question_id = $q_id");
    $options = [];
    while ($opt = $options_res->fetch_assoc()) {
        $options[] = $opt;
    }
    $q['options'] = $options;
    $questions[] = $q;
}

$total_questions = count($questions);
if ($current >= $total_questions) {
    header("Location: submit-quiz.php?task_id=$task_id");
    exit();
}

$current_question = $questions[$current];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($task['task_title']) ?> - Quiz</title>
    <link rel="stylesheet" href="question-style.css">
</head>
<body>
    <div class="quiz-container">
        <div class="top-bar">
            <div class="user-info">
                <img src="assets/profile.png" class="profile-icon" />
                <span>Hi,<br><strong><?= htmlspecialchars($_SESSION['user_name'] ?? 'User') ?></strong></span>
            </div>
            <div class="quiz-header">
                <h1><?= htmlspecialchars($task['task_title']) ?></h1>
                
            </div>
            <a class="back-button" href="user-dashboard.php">BACK</a>
        </div>

        <div class="question-section">
            <div class="question-box">
                <div class="question-number">
                    <?= ($current + 1) ?>/<?= $total_questions ?>
                </div>
                <div class="question-text">
                    <p><strong><?= htmlspecialchars($current_question['question_text']) ?></strong></p>
                </div>
            </div>

            <form method="POST" action="save-answer.php">
                <input type="hidden" name="task_id" value="<?= $task_id ?>">
                <input type="hidden" name="q_index" value="<?= $current ?>">
                <input type="hidden" name="question_id" value="<?= $current_question['id'] ?>">

                <div class="options">
                    <?php foreach ($current_question['options'] as $opt): ?>
                        <label class="option">
                            <input type="radio" name="selected_option" value="<?= $opt['id'] ?>"
                                <?= ($_SESSION['answers'][$current_question['id']] ?? '') == $opt['id'] ? 'checked' : '' ?> required>
                            <span><?= htmlspecialchars($opt['option_text']) ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>

                <div class="navigation-buttons">
                    <?php if ($current > 0): ?>
                        <a href="start-quiz.php?task_id=<?= $task_id ?>&q=<?= $current - 1 ?>" class="nav-btn">Previous</a>
                    <?php endif; ?>

                    <button type="submit" class="nav-btn">
                        <?= $current + 1 == $total_questions ? 'Submit' : 'Next' ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>