<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $q_id = intval($_POST['question_id']);
    $selected_option = intval($_POST['selected_option']);
    $_SESSION['answers'][$q_id] = $selected_option;

    $task_id = intval($_POST['task_id']);
    $q_index = intval($_POST['q_index']) + 1;
    header("Location: start-quiz.php?task_id=$task_id&q=$q_index");
    exit();
} else {
    echo "Invalid Request!";
}
