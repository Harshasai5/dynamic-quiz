<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: user-login.php");
    exit();
}

if (!isset($_GET['task_id'])) {
    echo "Task not specified.";
    exit();
}

$user_id = $_SESSION['user_id'];
$task_id = intval($_GET['task_id']);

// Get user name if available
$user_name = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'USER NAME';

// Get task info
$task_res = $conn->query("SELECT * FROM tasks WHERE id = $task_id");
$task = $task_res->fetch_assoc();

// Count user score
$sql = "SELECT ua.user_answer, ua.correct_answer
        FROM user_attempts ua
        WHERE ua.user_id = $user_id AND ua.task_id = $task_id";

$result = $conn->query($sql);

$total = 0;
$correct = 0;

while ($row = $result->fetch_assoc()) {
    $total++;
    if ($row['user_answer'] == $row['correct_answer']) {
        $correct++;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Task Result - <?= htmlspecialchars($task['task_title']) ?></title>
    <link rel="stylesheet" href="task-result-style.css">
</head>
<body>
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="user-info">
            <img src="assets/profile.png" class="profile-icon" alt="Profile" />
            <div>
                <div class="greeting">Hi,</div>
                <div class="username"><?= htmlspecialchars($user_name) ?></div>
            </div>
        </div>
        <a href="user-dashboard.php" class="back-btn">BACK</a>
    </div>

    <!-- Center Content -->
    <div class="result-container">
        <h1><?= strtoupper($task['task_title']) ?></h1>
        <h2>Congratulations</h2>
        <p class="subtext">Successfully completed <?= htmlspecialchars($task['task_title']) ?></p>

        <div class="score-circle">
            <?= $correct ?> / <?= $total ?>
        </div>
    </div>
</body>
</html>
