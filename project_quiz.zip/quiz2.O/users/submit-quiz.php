<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: user-login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if (isset($_GET['task_id']) && !empty($_SESSION['answers'])) {
    $task_id = intval($_GET['task_id']);
    $answers = $_SESSION['answers'];

    foreach ($answers as $question_id => $selected_option_id) {
        $question_id = intval($question_id);
        $selected_option_id = intval($selected_option_id);

        // Fetch user answer text
        $opt_result = $conn->query("SELECT option_text FROM options WHERE id = $selected_option_id");
        $user_answer = $opt_result && $opt_result->num_rows > 0 ? $opt_result->fetch_assoc()['option_text'] : '';

        // Fetch correct answer text
        $correct_result = $conn->query("SELECT option_text FROM options WHERE question_id = $question_id AND is_correct = 1");
        $correct_answer = $correct_result && $correct_result->num_rows > 0 ? $correct_result->fetch_assoc()['option_text'] : '';

        // Insert only if not already present
        $check = $conn->prepare("SELECT id FROM user_attempts WHERE user_id=? AND task_id=? AND question_id=?");
        $check->bind_param("iii", $user_id, $task_id, $question_id);
        $check->execute();
        $check_result = $check->get_result();

        if ($check_result->num_rows == 0) {
            $stmt = $conn->prepare("INSERT INTO user_attempts (user_id, task_id, question_id, user_answer, correct_answer) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("iiiss", $user_id, $task_id, $question_id, $user_answer, $correct_answer);
            $stmt->execute();
        }
    }

    // Clear session answers
    unset($_SESSION['answers']);

    // Redirect to result
    header("Location: task-result.php?task_id=$task_id");
    exit();
} else {
    echo "Invalid quiz submission! Please make sure you answered all questions.";
}
