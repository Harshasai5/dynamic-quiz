<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['course_id'])) {
    echo "Invalid request.";
    exit();
}

$user_id = $_SESSION['user_id'];
$course_id = intval($_GET['course_id']);

// Fetch course name
$course_name = $conn->query("SELECT course_name FROM courses WHERE id = $course_id")->fetch_assoc()['course_name'] ?? 'Course';

// Fetch tasks
$tasks = $conn->query("SELECT * FROM tasks WHERE course_id = $course_id");

// Check which tasks user has already attempted
$attempted = [];
$res = $conn->query("SELECT DISTINCT task_id FROM user_attempts WHERE user_id = $user_id");
while ($row = $res->fetch_assoc()) {
    $attempted[] = $row['task_id'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($course_name) ?> Tasks</title>
    <link rel="stylesheet" href="task-style.css">
</head>
<body>
    <div class="top-bar">
        <div class="user-info">
            <img src="assets/profile.png" class="profile-icon" />
            <span>Hi, <?= htmlspecialchars($_SESSION['user_name'] ?? 'User') ?></span>
        </div>
        <a href="user-dashboard.php" class="back-button">← BACK</a>
    </div>

    <h1 class="course-title"><?= htmlspecialchars($course_name) ?></h1>
    <p class="course-subtitle">the world of web structure</p>

    <div class="task-container">
        <?php
        $i = 1;
        while ($t = $tasks->fetch_assoc()):
            $isDone = in_array($t['id'], $attempted);
        ?>
        <div class="task-item">
            <div class="task-number">Task - <?= $i++ ?></div>
            <div class="task-title"><?= htmlspecialchars($t['task_title']) ?></div>
            <div class="task-icon">
                <?php if ($isDone): ?>
                    ✔️
                <?php else: ?>
                    ➡️
                <?php endif; ?>
            </div>
            <a href="start-quiz.php?task_id=<?= $t['id'] ?>" class="task-link"></a>
        </div>
        <?php endwhile; ?>
    </div>
</body>
</html>
