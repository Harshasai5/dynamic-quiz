<?php
include 'auth-check.php';
include 'includes/db.php';

// Handle Add or Edit
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    $task_id = $_POST['task_id'];
    $question_text = $_POST['question_text'];
    $options = $_POST['options'];
    $correct_option = $_POST['correct'];

    if ($_POST['action'] == 'add') {
        $stmt = $conn->prepare("INSERT INTO questions (task_id, question_text) VALUES (?, ?)");
        $stmt->bind_param("is", $task_id, $question_text);
        $stmt->execute();
        $question_id = $stmt->insert_id;
    } elseif ($_POST['action'] == 'edit') {
        $question_id = $_POST['question_id'];
        $stmt = $conn->prepare("UPDATE questions SET task_id = ?, question_text = ? WHERE id = ?");
        $stmt->bind_param("isi", $task_id, $question_text, $question_id);
        $stmt->execute();

        $conn->query("DELETE FROM options WHERE question_id = $question_id");
    }

    // Insert new options
    foreach ($options as $key => $value) {
        $is_correct = ($key == $correct_option) ? 1 : 0;
        $stmt_opt = $conn->prepare("INSERT INTO options (question_id, option_text, is_correct) VALUES (?, ?, ?)");
        $stmt_opt->bind_param("isi", $question_id, $value, $is_correct);
        $stmt_opt->execute();
    }

    header("Location: manage-questions.php");
    exit();
}

// Handle Delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM questions WHERE id = $id");
    $conn->query("DELETE FROM options WHERE question_id = $id");
    header("Location: manage-questions.php");
    exit();
}

// Load Questions, Tasks, Courses
$questions = $conn->query("
    SELECT 
        questions.*, 
        tasks.task_title, 
        courses.course_name,
        tasks.course_id
    FROM questions 
    JOIN tasks ON questions.task_id = tasks.id
    JOIN courses ON tasks.course_id = courses.id
");

$courses = $conn->query("SELECT * FROM courses");
$tasks = $conn->query("SELECT * FROM tasks");

// Editing
$edit_question = null;
$edit_options = [];
if (isset($_GET['edit'])) {
    $edit_id = intval($_GET['edit']);
    $res = $conn->query("SELECT * FROM questions WHERE id = $edit_id");
    $edit_question = $res->fetch_assoc();

    $opt_res = $conn->query("SELECT * FROM options WHERE question_id = $edit_id");
    while ($opt = $opt_res->fetch_assoc()) {
        $edit_options[] = $opt;
    }

    $task_res = $conn->query("SELECT * FROM tasks WHERE id = " . $edit_question['task_id']);
    $task_row = $task_res->fetch_assoc();
    $edit_course_id = $task_row['course_id'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Questions</title>
    <link rel="stylesheet" href="admin-style.css">
    <link rel="stylesheet" href="questions.css">
    <script>
        function filterTasksByCourse(courseId) {
            var taskOptions = document.querySelectorAll("#taskSelect option");
            taskOptions.forEach(opt => {
                opt.style.display = (opt.dataset.course == courseId || opt.value === '') ? "block" : "none";
            });
        }

        // Auto filter tasks when editing
        window.onload = function () {
            const selectedCourse = document.querySelector("select[name='course_id']").value;
            if (selectedCourse) filterTasksByCourse(selectedCourse);
        };
    </script>
</head>
<body>
    <h2><?= $edit_question ? 'Edit' : 'Add' ?> Question</h2>

    <form method="POST">
        <textarea name="question_text" placeholder="Question" required><?= htmlspecialchars($edit_question['question_text'] ?? '') ?></textarea><br>

        <?php for ($i = 0; $i < 4; $i++):
            $value = $edit_options[$i]['option_text'] ?? '';
            $is_correct = $edit_options[$i]['is_correct'] ?? 0;
        ?>
            <input type="text" name="options[]" placeholder="Option <?= $i + 1 ?>" value="<?= htmlspecialchars($value) ?>" required>
            <input type="radio" name="correct" value="<?= $i ?>" <?= $is_correct ? 'checked' : '' ?>> Correct<br>
        <?php endfor; ?>

        <select name="course_id" onchange="filterTasksByCourse(this.value)" required>
            <option value="">Select Course</option>
            <?php
            $courses->data_seek(0);
            while ($c = $courses->fetch_assoc()): ?>
                <option value="<?= $c['id'] ?>" <?= isset($edit_course_id) && $edit_course_id == $c['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($c['course_name']) ?>
                </option>
            <?php endwhile; ?>
        </select><br>

        <select name="task_id" id="taskSelect" required>
            <option value="">Select Task</option>
            <?php
            $tasks->data_seek(0);
            while ($t = $tasks->fetch_assoc()): ?>
                <option value="<?= $t['id'] ?>" data-course="<?= $t['course_id'] ?>" <?= isset($edit_question['task_id']) && $edit_question['task_id'] == $t['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($t['task_title']) ?>
                </option>
            <?php endwhile; ?>
        </select><br>

        <?php if ($edit_question): ?>
            <input type="hidden" name="question_id" value="<?= $edit_question['id'] ?>">
            <input type="hidden" name="action" value="edit">
            <button type="submit">Update Question</button>
            <a href="manage-questions.php">Cancel</a>
        <?php else: ?>
            <input type="hidden" name="action" value="add">
            <button type="submit">Add Question</button>
        <?php endif; ?>
    </form>

    <h3>All Questions</h3>
    <table border="1">
        <tr><th>ID</th><th>Question</th><th>Course</th><th>Task</th><th>Actions</th></tr>
        <?php while ($row = $questions->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['question_text']) ?></td>
                <td><?= htmlspecialchars($row['course_name']) ?></td>
                <td><?= htmlspecialchars($row['task_title']) ?></td>
                <td>
                    <a href="?edit=<?= $row['id'] ?>" class="btn btn-edit">Edit</a>
                    <a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this question?')" class="btn btn-delete">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <button type="button" class="btn btn-tsk"><a href="manage-tasks.php">← Back to Tasks</a></button>
</body>
</html>
