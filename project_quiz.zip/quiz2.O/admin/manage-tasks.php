<?php
include 'auth-check.php';
include 'includes/db.php';

// Handle Add/Edit Task
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $course_id = $_POST['course_id'];

    if ($id == "") {
        $stmt = $conn->prepare("INSERT INTO tasks (course_id, task_title) VALUES (?, ?)");
        $stmt->bind_param("is", $course_id, $title);
        $stmt->execute();
    } else {
        $stmt = $conn->prepare("UPDATE tasks SET course_id=?, task_title=? WHERE id=?");
        $stmt->bind_param("isi", $course_id, $title, $id);
        $stmt->execute();
    }

    header("Location: manage-tasks.php?course_id=" . $course_id);
    exit();
}

// Handle Delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM tasks WHERE id=$id");
    header("Location: manage-tasks.php?course_id=" . ($_GET['course_id'] ?? ''));
    exit();
}

// Fetch Courses
$courses = $conn->query("SELECT * FROM courses");

// Determine course filter
$course_id_filter = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
if ($course_id_filter > 0) {
    $stmt = $conn->prepare("SELECT tasks.*, courses.course_name AS course_name FROM tasks JOIN courses ON tasks.course_id = courses.id WHERE course_id = ?");
    $stmt->bind_param("i", $course_id_filter);
    $stmt->execute();
    $tasks = $stmt->get_result();
} else {
    $tasks = $conn->query("SELECT tasks.*, courses.course_name AS course_name FROM tasks JOIN courses ON tasks.course_id = courses.id");
}
?>

<h2>Manage Tasks <?= $course_id_filter ? "for Course ID $course_id_filter" : '' ?></h2>
<link rel="stylesheet" href="admin-style.css">

<!-- Task Form -->
<form method="POST">
    <input type="hidden" name="id" value="<?= $_GET['edit'] ?? '' ?>">
    <input type="text" name="title" placeholder="Task Title" required value="<?= $_GET['title'] ?? '' ?>">

    <select name="course_id" required>
        <option value="">Select Course</option>
        <?php
        // Reset result pointer for re-looping
        $courses->data_seek(0);
        while ($c = $courses->fetch_assoc()):
        ?>
            <option value="<?= $c['id'] ?>"
                <?= ((isset($_GET['course_id']) && $_GET['course_id'] == $c['id']) || (isset($_GET['edit']) && isset($_GET['course_id']) && $_GET['course_id'] == $c['id'])) ? 'selected' : '' ?>>
                <?= htmlspecialchars($c['course_name']) ?>
            </option>
        <?php endwhile; ?>
    </select>

    <button type="submit"><?= isset($_GET['edit']) ? "Update" : "Add" ?> Task</button>
</form>

<!-- Task List -->
<table border="1">
    <tr><th>ID</th><th>Title</th><th>Course</th><th>Created At</th><th>Actions</th></tr>
    <?php while ($row = $tasks->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['task_title']) ?></td>
            <td><?= htmlspecialchars($row['course_name']) ?></td>
            <td><?= $row['created_at'] ?></td>
            <td>
                <a href="?edit=<?= $row['id'] ?>" class="btn btn-edit">Edit</a>
                <a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this item?')" class="btn btn-delete">Delete</a>
                <a href="manage-questions.php?task_id=<?= $row['id'] ?>&course_id=<?= $row['course_id'] ?>" class="btn btn-que">Questions</a>
            </td>

        </tr>
    <?php endwhile; ?>
</table>

<button type="button" class="btn btn-cou"><a href="manage-courses.php">← Back to Courses</a></button>