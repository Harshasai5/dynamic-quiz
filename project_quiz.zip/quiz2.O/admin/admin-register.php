<?php
include 'includes/db.php';

// Only run once to create a new admin
$username = 'harsha';  // Change to your desired username
$password_plain = 'harsha0501';  // Change to your desired password

// Hash the password
$password_hashed = password_hash($password_plain, PASSWORD_DEFAULT);

// Insert into DB
$stmt = $conn->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
$stmt->bind_param("ss", $username, $password_hashed);

if ($stmt->execute()) {
    echo "✅ Admin '$username' registered successfully!";
} else {
    echo "❌ Error: " . $stmt->error;
}
