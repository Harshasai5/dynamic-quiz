<?php include 'auth-check.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>

<div class="sidebar">
    <h2>Admin Panel</h2>
    <ul>
        <li><a href="manage-courses.php">Manage Courses</a></li>
        <li><a href="manage-tasks.php">Manage Tasks</a></li>
        <li><a href="manage-questions.php">Manage Questions & Options</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</div>

<div class="main-content">
    <h1>Welcome, Admin 👋</h1>
    <p>Use the menu on the left to manage your platform.</p>
</div>

</body>
</html>
