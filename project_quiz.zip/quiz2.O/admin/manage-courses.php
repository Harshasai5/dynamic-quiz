<?php
include 'auth-check.php';
include 'includes/db.php';

// Handle Add/Edit Course
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course_name = $_POST['course_name'];
    $id = $_POST['id'];

    if ($id == "") {
        $stmt = $conn->prepare("INSERT INTO courses (course_name) VALUES (?)");
        $stmt->bind_param("s", $course_name);
        $stmt->execute();
    } else {
        $stmt = $conn->prepare("UPDATE courses SET course_name=? WHERE id=?");
        $stmt->bind_param("si", $course_name, $id);
        $stmt->execute();
    }
    header("Location: manage-courses.php");
    exit();
}

// Handle Delete Course
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM courses WHERE id=$id");
    header("Location: manage-courses.php");
    exit();
}

// Fetch all courses
$courses = $conn->query("SELECT * FROM courses");
?>

<h2>Manage Courses</h2>
<link rel="stylesheet" href="admin-style.css">

<!-- Add/Edit Form -->
<form method="POST">
    <input type="hidden" name="id" value="<?= $_GET['edit'] ?? '' ?>">
    <input type="text" name="course_name" placeholder="Course Name" required value="<?= $_GET['course_name'] ?? '' ?>">
    <button type="submit"><?= isset($_GET['edit']) ? "Update" : "Add" ?> Course</button>
</form>

<!-- Course List -->
<table border="1">
    <tr>
        <th>ID</th>
        <th>Course Name</th>
        <th>Created At</th>
        <th>Actions</th>
        <th>Manage Tasks</th>
    </tr>
    <?php while ($row = $courses->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['course_name']) ?></td>
            <td><?= $row['created_at'] ?></td>
            <td>
                 <a href="?edit=<?= $row['id'] ?>" class="btn btn-edit">Edit</a>
                <a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this item?')" class="btn btn-delete">Delete</a>
            </td>
            <td>
                <a href="manage-tasks.php?course_id=<?= $row['id'] ?>" class="btn btn-t">Manage Tasks</a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

<button type="button" class="btn btn-dash"><a href="dashboard.php">← Back to Dashboard</a></button>